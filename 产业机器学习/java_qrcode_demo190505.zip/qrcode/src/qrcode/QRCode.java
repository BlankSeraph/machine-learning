package qrcode;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.EncodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

/**
 * 二维码生成和读取示例
 *
 */
public class QRCode {

	public static boolean createQRCode(OutputStream outputStream, String content, int qrCodeSize, String imageFormat)
			throws WriterException, IOException {
		Map<EncodeHintType, Object> hintMap = new HashMap<EncodeHintType, Object>();// 参数
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L); // 容错级别
		hintMap.put(EncodeHintType.CHARACTER_SET, "utf-8");// 编码
		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		// 创建比特矩阵(位矩阵)的QR码编码的字符串
		BitMatrix bitMatrix = qrCodeWriter.encode(content, BarcodeFormat.QR_CODE, qrCodeSize, qrCodeSize, hintMap);
		// 使BufferedImage勾画QRCode (matrixWidth 是行二维码像素点)
		int matrixWidth = bitMatrix.getWidth();
		BufferedImage image = new BufferedImage(matrixWidth - 200, matrixWidth - 200, BufferedImage.TYPE_INT_RGB);
		image.createGraphics();
		Graphics2D graphics = (Graphics2D) image.getGraphics();
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, matrixWidth, matrixWidth);
		// 使用比特矩阵画并保存图像
		graphics.setColor(Color.BLACK);
		for (int i = 0; i < matrixWidth; i++) {
			for (int j = 0; j < matrixWidth; j++) {
				if (bitMatrix.get(i, j)) {
					graphics.fillRect(i - 100, j - 100, 1, 1);
				}
			}
		}
		return ImageIO.write(image, imageFormat, outputStream);
	}

	/**
	 * 读二维码并输出携带的信息
	 */
	public static void readQRCode(InputStream inputStream) throws IOException {
		// 从输入流中获取字符串信息
		BufferedImage image = ImageIO.read(inputStream);
		// 将图像转换为二进制位图源
		LuminanceSource source = new BufferedImageLuminanceSource(image);
		BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
		QRCodeReader reader = new QRCodeReader();
		Result result = null;
		try {
			Map<DecodeHintType, Object> hintMap = new HashMap<DecodeHintType, Object>();
			hintMap.put(DecodeHintType.CHARACTER_SET, "GB2312");
//            hintMap.put(DecodeHintType.CHARACTER_SET,"BIG5");
//            hintMap.put(DecodeHintType.CHARACTER_SET,"GBK");
//            hintMap.put(DecodeHintType.CHARACTER_SET,"GB18030");
//            hintMap.put(DecodeHintType.CHARACTER_SET,"Unicode");
//            hintMap.put(DecodeHintType.CHARACTER_SET,"UTF-8");
			result = reader.decode(bitmap, hintMap);

//         result = reader.decode(bitmap);  
		} catch (ReaderException e) {
			e.printStackTrace();
		}
		System.out.println(result.getText());

//		System.out.println(new String(result.getText().getBytes("ISO8859-1"),"GB2312"));//zxing默认字符集ISO8859-1，（内蒙）食品经营许可证使用了GB2312
	}

	public static void main(String[] args) throws IOException, WriterException {
//        createQrCode(new FileOutputStream(new File("/Users/caiwei/Documents/PycharmProjects/crawler/qrcode.jpg")),"hello你好world",900,"JPEG");
//        readQrCode(new FileInputStream(new File("/Users/caiwei/Documents/PycharmProjects/crawler/qrcode.jpg")));   
//		readQrCode(new FileInputStream(new File("/Users/caiwei/Documents/PycharmProjects/crawler/hrb.png")));//（哈尔滨18版）营业执照使用了UTF-8
//		readQrCode(new FileInputStream(new File("/Users/caiwei/Documents/PycharmProjects/crawler/1.png")));// （内蒙）食品经营许可证使用了GB2312
		readQRCode(new FileInputStream(new File("/Users/caiwei/Documents/PycharmProjects/crawler/original.jpeg")));// 可以自动定位二维码进行识别
	}

}